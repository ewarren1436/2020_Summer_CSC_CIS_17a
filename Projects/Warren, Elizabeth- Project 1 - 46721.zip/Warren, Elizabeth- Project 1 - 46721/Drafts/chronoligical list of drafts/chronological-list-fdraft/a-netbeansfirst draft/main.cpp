// This program simulates rolling dice.
#include <iostream>
#include <cstdlib>     // For rand and srand
#include <ctime>       // For the time function
#include<iomanip>       //for output formatting
using namespace std;

int main()
{
   // Constants
   const int MIN_VALUE = 1;   // Minimum die value
   const int MAX_VALUE = 6;   // Maximum die value
   //the yartzee game is composed of 5 dice
   // declare the five variables
   int die1;   // To hold the value of die #1
   int die2;   // To hold the value of die #2
   int die3;   // To hold the value of die #3
   int die4;   // To hold the value of die #2
   int die5;   // To hold the value of die #2
   //after user rolls
   int sav1,sav2,sav3,sav4,sav5;
   int choice;
   int number=5;
   int arr[number];
   // Get the system time.
   unsigned seed = time(0);
   
   // Seed the random number generator.
   srand(seed);
   
   cout << "Rolling the dice...\n";
   die1 = (rand() % (MAX_VALUE - MIN_VALUE + 1)) + MIN_VALUE;
   die2 = (rand() % (MAX_VALUE - MIN_VALUE + 1)) + MIN_VALUE;
   die3 = (rand() % (MAX_VALUE - MIN_VALUE + 1)) + MIN_VALUE;
   die4 = (rand() % (MAX_VALUE - MIN_VALUE + 1)) + MIN_VALUE;
   die5 = (rand() % (MAX_VALUE - MIN_VALUE + 1)) + MIN_VALUE;
   //output the dice to the user
   cout<<die1<< endl;
   cout<<die2<<endl;
   cout<<die3<<endl;
   cout<<die4<<endl;
   cout<<die5<<endl;

   cout<<"|Dice#1|"<<"|Dice#2|"<<"|Dice#3|"<<"|Dice#4|"<<"|Dice#5|"<<endl;
   cout<<die1<<setw(5)<<"     \t"<<die2<<setw(5)<<"     \t"<<die3
   <<setw(5)<<"      \t"<<die4<<setw(5)<<"      \t"<<die5<<endl;
  
   cout<<"Start with the first value and enter if you want to save";
   for( int i=0; i<5; i++){
   cin>>choice;
   if (choice==1){//enter if loop
    
   //*****************************************************************
    switch (die1){
   case 1:
   {sav1=die1;
   break;}
   case 2:
   {sav1=die1;
   break;}
   case 3:
   {sav1=die1;
   break;}
   case 4:
   {sav1=die1;
   break;}
   case 5:
   {sav1=die1;
   break;}
   case 6:
   {sav1=die1;
   break;}}
 
   //*****************************************************************
       switch (die2){
   case 1:
   {sav2=die2;
   break;}
   case 2:
   {sav2=die2;
   break;}
   case 3:
   {sav2=die2;
   break;}
   case 4:
   {sav2=die2;
   break;}
   case 5:
   {sav2=die2;
   break;}
   case 6:
   {sav2=die2;
   break;}}
   //*****************************************************************
   switch(die3){
    case 1:
   {sav3=die3;
   break;}
   case 2:
   {sav3=die3;
   break;}
   case 3:
   {sav3=die3;
   break;}
   case 4:
   {sav3=die3;
   break;}
   case 5:
   {sav3=die3;
   break;}
   case 6:
   {sav3=die3;
   break;}}
   //*****************************************************************
   switch(die4){
    case 1:
   {sav4=die4;
   break;}
   case 2:
   {sav4=die4;
   break;}
   case 3:
   {sav4=die4;
   break;}
   case 4:
   {sav4=die4;
   break;}
   case 5:
   {sav4=die4;
   break;}
   case 6:
   {sav4=die4;
   break;}}
//***************************************************************** 
switch(die5){
    case 1:
   {sav5=die5;
   break;}
   case 2:
   {sav5=die5;
   break;}
   case 3:
   {sav5=die5;
   break;}
   case 4:
   {sav5=die5;
   break;}
   case 5:
   {sav5=die5;
   break;}
   case 6:
   {sav5=die5;
   break;}}
   }//exit if loop
   }//exit for loop
   
   
   return 0;
}
    
