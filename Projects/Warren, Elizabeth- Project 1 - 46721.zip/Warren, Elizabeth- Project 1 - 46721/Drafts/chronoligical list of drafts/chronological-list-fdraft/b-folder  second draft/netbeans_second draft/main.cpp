// This program simulates rolling dice.
#include <iostream>
#include <cstdlib>     // For rand and srand
#include <ctime>       // For the time function
#include<iomanip>       //for output formatting
#include<vector>
using namespace std;

int main()
{
    // Get the system time.
    unsigned seed = time(0);
    // Seed the random number generator.
    srand(seed);
    //declare variables
    const int MAX_VALUE=6;
    const int MIN_VALUE=1;
    int num=5;
    //declare an array
    int arr[num];
        //declare a  to hold the values the player want
    vector<int>list; 
    //declare variables for branching
    char choice;
    
    //first roll
    //dice roll dictated by rand()   
      for(int i=0; i<num; i++){
      arr[i]=(rand() % (MAX_VALUE - MIN_VALUE + 1)) + MIN_VALUE;}
      for(int i=0;i<num; i++){
      cout<<arr[i]<<endl;}
        //Lets see what the player rolled
      cout<<"|Dice#1|\t"<<"|Dice#2|\t"<<"|Dice#3|\t"<<"|Dice#4|\t"
      <<"|Dice#5|\t"<<endl;
      for(int i=0; i<num; i++){
      cout<<arr[i]<<setw(5)<<"\t\t";}
      cout<<"Hello user decide if you want to save the number"<<endl;
      for(int i=0; i<5; i++){
      cout<<"Do you want to hold "<<arr[i]<<"?"<<endl;
      cin>>choice;
      if(choice=='y' || choice=='Y'){                  
      list.push_back(arr[i]);}
      }//end for loop 
      cout<<"The contents ofthe vector are: ";
      for(int i=0; i<list.size(); i++){
      cout<<list[i]<<endl;}
      int size = static_cast<int>(list.size());
  //***************************************************************************
  //second roll get size of vector
 //lets see what the play a second time   
      cout<<"The value is: "<<size;
      
   
     
     // for(int i=0;i<4; i++){
     // arr2[i]=(rand() % (MAX_VALUE - MIN_VALUE + 1)) + MIN_VALUE;}
     // for(int i=0; i<total; i++){
         // cout<<arr[i];
      //}
      

//exit files
return 0;
}
