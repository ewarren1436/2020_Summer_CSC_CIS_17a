// This program simulates rolling dice.
#include <iostream>
#include <cstdlib>     // For rand and srand
#include <ctime>       // For the time function
#include<iomanip>       //for output formatting
#include<vector>
using namespace std;
//function prototypes
  void disR1(int[], int);
  void disR1V(vector<int>);//display the held dice after first roll  
  void disResult(int *,int);//display the dice after second roll


//***see if you need to remove it
int main()
{
    // Get the system time.
    unsigned seed = time(0);
    // Seed the random number generator.
    srand(seed);
    
    //declare variables for random seed
    const int MAX_VALUE=6;
    const int MIN_VALUE=1;
    //this hold hold size of array for first throw(5 dice)
      const int num=5;
      
    //declare an array for first roll of dice
     int arr[num]; 
     
    //declare a dynamic to hold the values the player want to keep from 1 roll
      vector<int>list; 
      char choice;
      
    //declare variables for if branching(enable user to hold dice)
    //after play this game, maybe user is happy with the dice hold
    //wants to change his roll hold
      char again;
        
    //first roll
    //dice roll dictated by rand()   
      for(int i=0; i<num; i++){
      arr[i]=(rand() % (MAX_VALUE - MIN_VALUE + 1)) + MIN_VALUE;}  
     
     //Lets see what the player rolled   
      cout<<"This is the display from the main"<<endl;
      disR1(arr, num);
      //Let the player to decide what they want to keep
      cout<<"what dice are going to hold?  Enter y to hold:"<<endl;       
      for(int i=0; i<5; i++){
      cout<<"Do you want to hold "<<arr[i]<<"?"<<endl;
      cin>>choice;
      if(choice=='y' || choice=='Y'){                  
      list.push_back(arr[i]);}      
      }//end for loop
      //mayber the user wants to change what he held lets ask him
      cout<<"Changed you mind on your hold.  Enter y"<<endl;
      cin>>again;
      if (again=='y' || again=='Y'){//enter if loop for changing values  
      //we have to clear the array .  Otherwise get duplicate values
      list.clear();
      for(int i=0; i<5; i++){
      cout<<"Do you want to hold "<<arr[i]<<"?"<<endl;
      cin>>choice;
      if(choice=='y' || choice=='Y'){                  
      list.push_back(arr[i]);}       
      }}//end for loop 
      //get size of vector for 2 reasons
      //reason 1 if player wants to roll again need size of second array
      //reason if player wants
      int size = static_cast<int>(list.size()); 
      if (size=5){
      cout<<"red"<<endl;//this is a stub to call results
      }
      //display the results of the vector
       disR1V(list);
      //**************************************************************************
      size = static_cast<int>(list.size());  
     //second roll get size of vector
     //lets see what the play a second time  
     cout<<"The size of the vector (held dice): "<<size<<endl;
     int size1=num-size;
     int *arr2=nullptr;
     arr2= new int[size1];     
     for(int i=0;i<size1; i++){
     arr2[i]=(rand() % (MAX_VALUE - MIN_VALUE + 1)) + MIN_VALUE;} 
     //function call to display the results after the second roll
     disResult(arr2,size1);
     disR1V(list);
     delete [] arr2;  

//exit files
return 0;
}
void disResult(int *a,int s)
{//enter function 
int * current=a;
for(int i=0; i<s; i++){
cout<<"Dice face value: "<<*current<<" (second roll) "<<endl;
current++;}
}//exit function
void disR1 (int a[],int s){       
      cout<<"Player rolled: "<<endl;
      for(int i=0; i<s; i++){
      cout<<"Dice face value: "<<a[i]<<endl;    
      }}

void disR1V(vector<int>l){    
      
      for(int i=0; i<l.size(); i++){
      cout<<"Dice face value: "<<l[i]<<" (held)"<<endl;}
      }
    

   

  
      
