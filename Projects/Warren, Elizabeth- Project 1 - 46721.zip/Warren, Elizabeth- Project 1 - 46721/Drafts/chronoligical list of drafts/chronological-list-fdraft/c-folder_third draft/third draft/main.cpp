// This program simulates rolling dice.
#include <iostream>
#include <cstdlib>     // For rand and srand
#include <ctime>       // For the time function
#include<iomanip>       //for output formatting
#include<vector>
using namespace std;
void disResult(int *,int);
int main()
{
int size=0;
int *arr2=nullptr;
//double *sales = nullptr
arr2= new int [size];
//sales = new double[numDays]
cout<<"Enter size";
cin>>size;
for(int i=0; i<size; i++){
cin>>arr2[i];}
//display results
disResult(arr2,  size);
return 0;
}
void disResult(int *a,int s)
{//enter function
int * current=a;
for(int i=0; i<s; i++){
cout<<*current<<endl;
current++;}
}//exit function