// This program simulates rolling dice.
#include <iostream>
#include <cstdlib>     // For rand and srand
#include <ctime>       // For the time function
#include<iomanip>       //for output formatting
#include<vector>
using namespace std;
//function prototypes
void disResult(int *,int);
void display ();

//***see if you need to remove it
int main()
{
    // Get the system time.
    unsigned seed = time(0);
    // Seed the random number generator.
    srand(seed);
    //declare variables for random seed
    const int MAX_VALUE=6;
    const int MIN_VALUE=1;
    //this hold hold size of  array (5 dice)
    const int num=5;    
    //declare an array for first roll of dice
     int arr[num];             
    //declare a dynamic to hold the values the player want
     vector<int>list; 
    //declare variables for if branching(enable user to hold dice)
     char choice;
    //after play this game, maybe user is happy with the dice hold
    //wants to change his roll hold
     char again;
      
    
    //first roll
    //dice roll dictated by rand()   
      for(int i=0; i<num; i++){
      arr[i]=(rand() % (MAX_VALUE - MIN_VALUE + 1)) + MIN_VALUE;}
     //for(int i=0;i<num; i++){
      //cout<<arr[i]<<endl;}
        //Lets see what the player rolled
      //cout<<"|Dice#1|\t"<<"|Dice#2|\t"<<"|Dice#3|\t"<<"|Dice#4|\t"
      //<<"|Dice#5|\t"<<endl;
      cout<<"player rolled: "<<endl;
      for(int i=0; i<num; i++){
      cout<<"Dice#"<<i+1<<" "<<arr[i]<<endl;    
      }
      //cout<<arr[i]<<setw(5)<<"\t\t";}   
      cout<<"what dice are going to hold?  Enter y to hold:"<<endl;       
      for(int i=0; i<5; i++){
      cout<<"Do you want to hold "<<arr[i]<<"?"<<endl;
      cin>>choice;
      if(choice=='y' || choice=='Y'){                  
      list.push_back(arr[i]);}      
      }//end for loop 
      cout<<"Changed you mind on your hold.  Enter y"<<endl;
      cin>>again;
      if (again=='y' || again=='Y')
      for(int i=0; i<5; i++){
      cout<<"Do you want to hold "<<arr[i]<<"?"<<endl;
      cin>>choice;
      if(choice=='y' || choice=='Y'){                  
      list.push_back(arr[i]);}      
      }//end for loop       
      cout<<"The contents of the vector are(held dice)= ";
      for(int i=0; i<list.size(); i++){
      cout<<list[i]<<"  ";}
      cout<<endl;
      int size = static_cast<int>(list.size());  
   //***************************************************************************
     //second roll get size of vector
     //lets see what the play a second time   
     cout<<"The value of the vecotr (held dice: "<<size<<endl;
     int size1=num-size;
     int *arr2=nullptr;
     arr2= new int[size1];     
     for(int i=0;i<size1; i++){
     arr2[i]=(rand() % (MAX_VALUE - MIN_VALUE + 1)) + MIN_VALUE;} 
     //function call to display the results after the second roll
     disResult(arr2,size1);
     display();
     delete [] arr2;  

//exit files
return 0;
}
void disResult(int *a,int s)
{//enter function
  cout<<"----------------------------------------"<<endl;
int * current=a;
for(int i=0; i<s; i++){
cout<<"Dice#"<<i+1<<" "<<*current<<" (second roll) "<<endl;
current++;}
cout<<"----------------------------------------"<<endl;
}//exit function
void display(){
    cout<<"this is a stub";
}
  
      
