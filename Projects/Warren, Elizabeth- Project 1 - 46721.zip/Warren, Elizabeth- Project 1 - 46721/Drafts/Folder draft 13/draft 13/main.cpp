/*
* File:   main.cpp
 * Author: Elizabeth Warren
 * Created on July 14, 2020, 11:10 PM
 * 
*/ 
#include <iostream>
#include <cstdlib>     // For rand and srand
#include <ctime>       // For the time function
#include<iomanip>       //for output formatting
#include<vector>
#include "Game.h"
using namespace std;
//function prototypes
  void getRoll (int [], int, const int, const int);//func. returns the rolled dice
  //void getScore ();
  void disR1(int[], int);//display the first roll dice value from random selection 
  void disR1V(vector<int>);//display the held dice after first roll  
  void disResult(int *,int);//display the dice roll after second roll
  void disR2V(vector<int>);//display the dice that held after third roll
  void disMenu();//display scoring category menu
  void getInfo(Game *);
int main()
{
   
     Game player;			// Define a structure instance   
  //declare variables    
    //variables for random seed
      //Get the system time.
       unsigned seed = time(0);
     //Seed the random number generator.
       srand(seed);
    //constant variables            
       const int MAX_VALUE=6; //hold max range for device           
       const int MIN_VALUE=1;//hold min ran for dice
       const int num=5; //this hold hold size of array =5 dice(first row of dice)
    //variables to hold size of vector
       int size,size1,size2, size3;       
    //first roll arrays and vectors 
      int arr[num];//declare an array for first roll of dice     
      vector<int>list;//hold values the player wants to keep from #1 roll 
    //second roll arrays and vectors
      vector<int>list2;//hold the values the player want to keep from #2 roll
      int *arr2=nullptr;
      arr2= new int[size1];
    //third roll arrays and vectors
      int *arr3=nullptr;
      arr3= new int[size3];
      vector<int>list3;
    //variables used in decision making
      char choice;//stores the 
 //***************************************************************************
 //for loop to loop through the 13 turn    
//***************************************************************************    
     //for loop to go through the 13 turns
      for( int i=0 ; i<13; i++){//enter for loop
      cout<<"******************************************************"<<endl;
      cout<<"\t Player This Is Your #"<<i+1<<" Turn"<<endl;
      cout<<"******************************************************"<<endl;
 //***************************************************************************
 //first roll    
//***************************************************************************
      cout<<"\t\t Dice Roll I"<<endl;
      //dice roll dictated by rand()       
      getRoll (arr,num, MAX_VALUE,MIN_VALUE);//this function will generate the dice #s for roll 1
     //Lets see what the player rolled  
       disR1(arr, num);//function call displays result from first roll
      //Let the player to decide what they want to keep
      //for loop used to reassign held values to vector
      cout<<"Player what dice are you going to hold?  Enter y to hold:"<<endl;       
      for(int i=0; i<num; i++){
      cout<<"Do you want to hold "<<arr[i]<<"?"<<endl;
      cin>>choice;           
      if(choice=='y' || choice=='Y'){                  
      list.push_back(arr[i]);}      
      }//end for loop
 
      //get size of vector for 2 reasons
      //reason 1 if player wants to roll again need size of second array
      //reason if player wants
      size = static_cast<int>(list.size()); 
      if (size==5){
          cout<<"User hold all her dice.  Input score."<<endl;
          disMenu();
          getInfo(& player);}   
      
      else if (size!=5) {// else if terminate at line 139   
//***************************************************************************
//Second Roll   
//***************************************************************************
      //get the size of the vector so we can size the dynamic array
      size = static_cast<int>(list.size());    
      cout<<"The size of the vector after first roll (held dice) "<<size<<endl;
      size1=num-size;        
      //now we can set aside some room on the heap for  the array for the roll #2       
      getRoll (arr2,size1, MAX_VALUE, MIN_VALUE);//this function will generate the dice #s for roll 2
      cout<<"Results after second roll:"<<endl;
      disR1V(list);    
      disResult(arr2,size1);
     //Let the player to decide what they want to keep after roll 2
      cout<<"Player what dice are you going to hold this time?  Enter y to hold:"<<endl;       
      for(int i=0; i<size1; i++){
      cout<<"Do you want to hold "<<arr2[i]<<"?"<<endl;
      cin>>choice;
      if(choice=='y' || choice=='Y'){                  
      list2.push_back(arr2[i]);}      
      }//end for loop
      disR1V(list);
      disR1V(list2);
 //***************************************************************************
 //Third Roll   
 //**************************************************************************
      cout<<"\t\t Dice Roll III"<<endl;
      size2 = static_cast<int>(list2.size());     
      cout<<"This is the value of after second roll: "<<size2<<endl;
      size3=num-(size2+size);    
     //if player has chosen all his dice display the menu            
      if (size3==0){
       disMenu();
       getInfo(& player);}		// user enter dice roll values.}     
      else if (size3!=0) {// else if terminate at line 139 
            
      //disR1V(list);
      //disR2V(list2);         
         
      cout<<"this will be the value of the third array"<<size3<<endl;   
      getRoll (arr3,size1, MAX_VALUE, MIN_VALUE);  
      cout<<"Results after third roll:"<<endl;
      disResult(arr3,size3);      
      cout<<"what dice are going to hold?  Enter y to hold:"<<endl;       
      for(int i=0; i<size3; i++){
      cout<<"Do you want to hold "<<arr3[i]<<"?"<<endl;
      cin>>choice;
      if(choice=='y' || choice=='Y'){                  
      list3.push_back(arr3[i]);}      
      }//end for loop 
      int size4 = static_cast<int>(list3.size());    
      cout<<"the value of the last vector is :"<<size4<<endl;
      cout<<"++==================YAHTZEE===============================++"<<endl;     
      cout<<"\t Final Values #"<<i+1<<" Turn"<<endl;  
      for(int i=0; i<size4; i++){
      cout<<"Dice face value: "<<list3[i]<<" (held)"<<endl;}      
      disR1V(list);
      disR2V(list2);
      disMenu();
      getInfo(& player);  
      cout<<"++==================YAHTZEE===============================++"<<endl; 
      
      //clear the vector for the next turn 
        list.clear();
        list2.clear();
        list3.clear();
      }//inner else if terminate here
      }//outer else if terminates here
     // cout<<"Yahtzee scores: "<<player.ones<<" "<<player.twos;
     // cout<<"  "<<player.threes<<"  "<<player.fours<<"  "<<player.fives;
      //cout<<"  "<<player.sixes<<endl;
      }//exit for loop   
      //output final values
  

      
      // delete dynamic array;
       delete [] arr2;  
       delete [] arr3;
//exit files
return 0;
}


void disResult(int *a,int s)
   {//enter function 
   int * current=a;
   for(int i=0; i<s; i++){
   cout<<"Dice face value: "<<*current<<endl;
   current++;}

}//exit function
void disR1 (int a[],int s){       
   cout<<"Player rolled: "<<endl;
   for(int i=0; i<s; i++){
   cout<<"Dice face value: "<<a[i]<<endl;    
   }}

void disR1V(vector<int>l){  
   for(int i=0; i<l.size(); i++){
   cout<<"Dice face value: "<<l[i]<<" (held)"<<endl;}
   }
    
void disR2V(vector<int>listb){
   for(int i=0; i<listb.size(); i++){
   cout<<"Dice face value: "<<listb[i]<<" (held)"<<endl;}}
void getRoll (int a[], int n, int MAX, int MIN){
   for(int i=0; i<n; i++){
   a[i]=(rand() % (MAX- MIN+ 1)) + MIN;}
}
void disMenu(){
   cout<<setw (20)<<right<<"Category"<< setw (16)<< right<<"Choice"<<endl;
   cout<<setw (16)<<right<<"Ones"<<setw(24)<<right<<"Enter 'a' " << endl;
   cout<<setw (16)<<right<<" Twos"<<setw(24)<<right<<"Enter 'b' " << endl;
   cout<<setw (16)<<right<<"Three"<<setw(24)<<right<<"Enter 'c' " << endl;
   cout<<setw (16)<<right<<"Fours"<<setw(24)<<right<<"Enter 'd' " << endl;
   cout<<setw (16)<<right<<"Fives"<<setw(24)<<right<<"Enter 'e' " << endl;
   cout<<setw (16)<<right<<"Sixes"<<setw(24)<<right<<"Enter 'f' " << endl;
   } 
void getInfo (Game *g) 
{  
//Game tempGame;//temporary structure variable
short int choice; 

cout << "Enter your choice" << endl;//user will give his choice
cin >> choice;
if(choice<1 || choice>5)
{cout<<"Please reenter choice."<<endl;
cin>>choice;}
// (choice<1 || choice>6); 
switch (choice)//switch statement will categorize use response
 {//enter switch statement   
case 1:{  
cout << "Receive 1 points for each 1 rolled.  Input sum. " << endl;
cin >> g->ones;
break;}     
    
case 2:{ 
cout << "Receive 2 points for each 2 rolled.  Input sum. " << endl;
cin >> g->twos;
break;}

case 3:{  
cout << "Receive 3 points for each 3 rolled.  Input sum. " << endl;
cin >> g->threes;
break;}     
    
case 4:{ 
cout << "Receive 4 points for each 4 rolled.  Input sum. " << endl;
cin >> g->fours;
break;} 

case 5:{  
cout << "Receive 5 points for each 5 rolled.  Input sum. " << endl;
cin >> g->fives;
break;}     
    
case 6:{ 
cout << "Receive 6 points for each 6 rolled.  Input sum. " << endl;	
cin >> g->sixes;
break;}  

default:{
cout << "You did not enter a,b,c,d,e, or f";}//exit switch statement
//return the temporary variable
//return tempGame;
}}

  
      

   

  
      
