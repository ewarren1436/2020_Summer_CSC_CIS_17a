// This program simulates rolling dice.
#include <iostream>
#include <cstdlib>     // For rand and srand
#include <ctime>       // For the time function
#include<iomanip>       //for output formatting
#include<vector>
using namespace std;
//function prototypes
  void getRoll (int [], int, const int, const int);void getRoll (int [], int, const int, const int);
  void disR1(int[], int);
  void disR1V(vector<int>);//display the held dice after first roll  
  void disResult(int *,int);//display the dice after second roll
  void disR2V(vector<int>);//display the dice that held after second roll
  

//***see if you need to remove it
int main()
{  
  //declare variables for random seed
    // Get the system time.
       unsigned seed = time(0);
    // Seed the random number generator.
       srand(seed);
    
 //declare variables             
       const int MAX_VALUE=6;            
       const int MIN_VALUE=1;
   
      //this hold hold size of array for first throw(5 dice)
        const int num=5;      
    //declare an array for first roll of dice
      int arr[num];      
    //declare a vector to hold the values the player want to keep from 1 roll
      vector<int>list;     
    //declare a vector to hold the values the player want to keep from second roll
      vector<int>list2; 
      char choice;
      vector<int>list3;
 
    //for loop 
      for( int i=0 ; i<3; i++){//enter for loop
      cout<<"******************************************************"<<endl;
      cout<<"\t Player This Is Your #"<<i+1<<" Turn"<<endl;
      cout<<"******************************************************"<<endl;
 //***************************************************************************
 //first roll    
//***************************************************************************
      cout<<"\t\t Dice Roll I"<<endl;
      //dice roll dictated by rand()       
      getRoll (arr,num, MAX_VALUE,MIN_VALUE);//this function will generate the dice #s for roll 1
     //Lets see what the player rolled  
       disR1(arr, num);//function call displays result from first roll
      //Let the player to decide what they want to keep
      cout<<"Player what dice are you going to hold?  Enter y to hold:"<<endl;       
      for(int i=0; i<num; i++){
      cout<<"Do you want to hold "<<arr[i]<<"?"<<endl;
      cin>>choice;
      if(choice=='y' || choice=='Y'){                  
      list.push_back(arr[i]);}      
      }//end for loop
 
      //get size of vector for 2 reasons
      //reason 1 if player wants to roll again need size of second array
      //reason if player wants
      int size = static_cast<int>(list.size()); 
      if (size==5){
      cout<<"red"<<endl;//this is a stub to call results
      }
//***************************************************************************
//Second Roll   
//***************************************************************************
    
    //get the size of the vector so we can size the dynamic array
      size = static_cast<int>(list.size());    
      cout<<"The size of the vector after first roll (held dice) "<<size<<endl;
      int  size1=num-size;
     // if (size1==0){//this is a temporary stub
       // exit (EXIT_FAILURE);}     
      //now we can set aside some room on the heap for  the array for the roll #2
      int *arr2=nullptr;
      arr2= new int[size1];   
      getRoll (arr2,size1, MAX_VALUE, MIN_VALUE);//this function will generate the dice #s for roll 2
      cout<<"Results after second roll:"<<endl;
      disR1V(list);    
      disResult(arr2,size1);
     //Let the player to decide what they want to keep after roll 2
      cout<<"Player what dice are you going to hold this time?  Enter y to hold:"<<endl;       
      for(int i=0; i<size1; i++){
      cout<<"Do you want to hold "<<arr2[i]<<"?"<<endl;
      cin>>choice;
      if(choice=='y' || choice=='Y'){                  
      list2.push_back(arr2[i]);}      
      }//end for loop
      disR1V(list);
      disR1V(list2);
 //***************************************************************************
 //Second Roll   
 //**************************************************************************
      cout<<"\t\t Dice Roll III"<<endl;
      int size2 = static_cast<int>(list2.size());     
      cout<<"This is the value of after second roll: "<<size2<<endl;
      int size3=num-(size2+size);
      //if (size3==0){            
      //disR1V(list);
      //disR2V(list2);         
      //exit (EXIT_FAILURE);}    
      cout<<"this will be the value of the third array"<<size3<<endl;
      int *arr3=nullptr;
      arr3= new int[size3]; 
      getRoll (arr3,size1, MAX_VALUE, MIN_VALUE);  
      cout<<"Results after third roll:"<<endl;
      disResult(arr3,size3);      
      cout<<"what dice are going to hold?  Enter y to hold:"<<endl;       
      for(int i=0; i<size3; i++){
      cout<<"Do you want to hold "<<arr3[i]<<"?"<<endl;
      cin>>choice;
      if(choice=='y' || choice=='Y'){                  
      list3.push_back(arr3[i]);}      
      }//end for loop 
      int size4 = static_cast<int>(list3.size());    
      cout<<"the value of the last vector is :"<<size4<<endl;
      cout<<"++==================YAHTZEE===============================++"<<endl;     
      cout<<"\t Final Values #"<<i+1<<" Turn"<<endl;  
      for(int i=0; i<size4; i++){
      cout<<"Dice face value: "<<list3[i]<<" (held)"<<endl;
      }
      disR1V(list);
      disR2V(list2);
       cout<<"++==================YAHTZEE===============================++"<<endl; 
      
      //clear the vector for the next turn 
        list.clear();
        list2.clear();
        list3.clear();
      }//exit for loop
 
       //delete dynamic array
      // delete [] arr2;  
      // delete [] arr3;
//exit files
return 0;
}
void disResult(int *a,int s)
{//enter function 
int * current=a;
for(int i=0; i<s; i++){
cout<<"Dice face value: "<<*current<<endl;
current++;}

}//exit function
void disR1 (int a[],int s){       
      cout<<"Player rolled: "<<endl;
      for(int i=0; i<s; i++){
      cout<<"Dice face value: "<<a[i]<<endl;    
      }}

void disR1V(vector<int>l){  
      for(int i=0; i<l.size(); i++){
      cout<<"Dice face value: "<<l[i]<<" (held)"<<endl;}
      }
    
void disR2V(vector<int>listb){
   for(int i=0; i<listb.size(); i++){
   cout<<"Dice face value: "<<listb[i]<<" (held)"<<endl;}}
void getRoll (int a[], int n, int MAX, int MIN){
    for(int i=0; i<n; i++){
    a[i]=(rand() % (MAX- MIN+ 1)) + MIN;}
}
   

  
      
