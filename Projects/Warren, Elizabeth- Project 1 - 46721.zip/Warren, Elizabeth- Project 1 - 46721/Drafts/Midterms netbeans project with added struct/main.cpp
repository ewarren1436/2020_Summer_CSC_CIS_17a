/*
* File:   main.cpp
 * Author: Elizabeth Warren
 * Created on July 14, 2020, 11:10 PM
 * 
*/ 
#include <iostream>
#include <cstdlib>     // For rand and srand
#include <ctime>       // For the time function
#include<iomanip>       //for output formatting
#include<vector>
#include<fstream>
#include "Game.h"
#include "ScorInfo.h"
using namespace std;
//function prototypes
  
  void getRoll (int [], int, const int, const int);//func. returns the rolled dice 
  void disR1(int[], int);//display the first roll dice value from random selection 
  void disR1V(vector<int>);//display the held dice after first roll  
  void disResult(int *,int);//display the dice roll after second roll
  void disR2V(vector<int>);//display the dice that held after third roll
  void disMenu();//display scoring category menu
  Game getInfo();
  void getScor (ScorInfo&, int);
  void prtScor (ScorInfo, string []);
  int getValue(int &);
int main()
{   
      Game a;
      ScorInfo player;   
      //int size=4;
      string card[]={"small straight", "large straight", "yahtzee", "bonus",
      "full house"};
      int choice1;
    // Define a structure instance   
  //declare variables    
    //variables for random seed
      //Get the system time.
       unsigned seed = time(0);
     //Seed the random number generator.
       srand(seed);
    //constant variables            
       const int MAX_VALUE=6; //hold max range for device           
       const int MIN_VALUE=1;//hold min ran for dice
       const int num=5; //this hold hold size of array =5 dice(first row of dice)
    //variables to hold size of vector
       int size,size1,size2, size3;       
    //first roll arrays and vectors 
      int arr[num];//declare an array for first roll of dice     
      vector<int>list;//hold values the player wants to keep from #1 roll 
    //second roll arrays and vectors
      vector<int>list2;//hold the values the player want to keep from #2 roll
      int *arr2=nullptr;
      arr2= new int[size1];
    //third roll arrays and vectors
      int *arr3=nullptr;
      arr3= new int[size3];
      vector<int>list3;
    //variables used in decision making
      char choice, input;//stores the
      int tallySum, finScore;//sum of structs
      int total;//hold the score so the struct does not get overloaded
 //***************************************************************************
 //for loop to loop through the 13 turn    
//***************************************************************************    
     //for loop to go through the 13 turns
      for( int i=0 ; i<13; i++){//enter for loop
      cout<<"******************************************************"<<endl;
      cout<<"\t Player This Is Your #"<<i+1<<" Turn"<<endl;
      cout<<"******************************************************"<<endl;
 //***************************************************************************
 //first roll    
//***************************************************************************
      cout<<"\t\t Dice Roll I"<<endl;
      //dice roll dictated by rand()       
      getRoll (arr,num, MAX_VALUE,MIN_VALUE);//this function will generate the dice #s for roll 1
     //Lets see what the player rolled  
       disR1(arr, num);//function call displays result from first roll
      //Let the player to decide what they want to keep
      //for loop used to reassign held values to vector
      cout<<"Player what dice are you going to hold?  Enter y to hold:"<<endl;       
      for(int i=0; i<num; i++){
      cout<<"Do you want to hold "<<arr[i]<<"?"<<endl;
      cin>>choice;           
      if(choice=='y' || choice=='Y'){                  
      list.push_back(arr[i]);}      
      }//end for loop
 
      //get size of vector for 2 reasons
      //reason 1 if player wants to roll again need size of second array
      //reason if player wants
      size = static_cast<int>(list.size()); 
          if (size==5){
          cout<<"User hold all her dice.  Input score."<<endl;
          disMenu();
          a = getInfo();}		// user enter dice roll values    
          
      
      else if (size!=5) {// else if terminate at line 139   
//***************************************************************************
//Second Roll   
//***************************************************************************
      //get the size of the vector so we can size the dynamic array
      size = static_cast<int>(list.size());    
      cout<<"The size of the vector after first roll (held dice) "<<size<<endl;
      size1=num-size;        
      //now we can set aside some room on the heap for  the array for the roll #2       
      getRoll (arr2,size1, MAX_VALUE, MIN_VALUE);//this function will generate the dice #s for roll 2
      cout<<"Results after second roll:"<<endl;
      disR1V(list);    
      disResult(arr2,size1);
     //Let the player to decide what they want to keep after roll 2
      cout<<"Player what dice are you going to hold this time?  Enter y to hold:"<<endl;       
      for(int i=0; i<size1; i++){
      cout<<"Do you want to hold "<<arr2[i]<<"?"<<endl;
      cin>>choice;
      if(choice=='y' || choice=='Y'){                  
      list2.push_back(arr2[i]);}      
      }//end for loop
      disR1V(list);
      disR1V(list2);
 //***************************************************************************
 //Third Roll   
 //**************************************************************************
      cout<<"\t\t Dice Roll III"<<endl;
      size2 = static_cast<int>(list2.size());     
      cout<<"This is the value of after second roll: "<<size2<<endl;
      size3=num-(size2+size);    
     //if player has chosen all his dice display the menu            
      if (size3==0){
          disMenu();
          a = getInfo();}		// user enter dice roll values.}     
      else if (size3!=0) {// else if terminate at line 139 
            
      //disR1V(list);
      //disR2V(list2);         
         
      cout<<"this will be the value of the third array"<<size3<<endl;   
      getRoll (arr3,size1, MAX_VALUE, MIN_VALUE);  
      cout<<"Results after third roll:"<<endl;
      disResult(arr3,size3);      
      cout<<"what dice are going to hold?  Enter y to hold:"<<endl;       
      for(int i=0; i<size3; i++){
      cout<<"Do you want to hold "<<arr3[i]<<"?"<<endl;
      cin>>choice;
      if(choice=='y' || choice=='Y'){                  
      list3.push_back(arr3[i]);}      
      }//end for loop 
      int size4 = static_cast<int>(list3.size());    
      cout<<"the value of the last vector is :"<<size4<<endl;
      cout<<"++==================YAHTZEE===============================++"<<endl;     
      cout<<"\t Final Values #"<<i+1<<" Turn"<<endl;  
      for(int i=0; i<size4; i++){
      cout<<"Dice face value: "<<list3[i]<<" (held)"<<endl;
      }
      disR1V(list);
      disR2V(list2);
      disMenu();
      a = getInfo();      
      cout<<"++==================YAHTZEE===============================++"<<endl; 
      
      //clear the vector for the next turn 
        list.clear();
        list2.clear();
        list3.clear();
      }//inner else if terminate here
      }//outer else if terminates here     
      }//exit for loop 
      cout<<"User enter points for fixed categories"<<endl;     
 
      //****************************************************8  
      cout<<"-----------------------------------"<<endl;
      for (int i=0; i<5; i++){//number of iterations
      cout<<"Enter choice";
      cin>>choice1;    
      getScor(player, choice1);}
      cout<<"-----------------------------------"<<endl;
      prtScor (player, card); 
      //*******************************************************************
           tallySum=a.ones+a.twos+a.threes+a.fours+a.fives+a.sixes+a.thkind
      + a.frkind;
      total=total=player.smlStrt+player.larStrt+player.yahtzee+
      player.bonus+player.fulHs;
      finScore=tallySum+total;
      cout<<"User final results are: "<<endl;
      cout<<"Ones=  "<<a.ones<<endl;
      cout<<"Twos=  "<<a.twos<<endl;
      cout<<"Threes= "<<a.threes<<endl;
      cout<<"Fours=  "<<a.fours<<endl;
      cout<<"Fives=  "<<a.fives<<endl;
      cout<<"Sixes=  "<<a.sixes<<endl;
      cout<<"3 of =  "<<a.thkind<<endl;
      cout<<"4 of =  "<<a.frkind<<endl;
      cout<<"Amount from upper section"<<tallySum<<endl;
      cout<<"Final Score\t"<<tallySum<<endl;      
      cout<<"This is the final score "<<finScore;
      fstream dataFile;
      dataFile.open("scores.txt", ios::out); // Open for output
      dataFile<<a.ones;
      dataFile<<a.twos;
      dataFile<<a.threes;
      dataFile<<a.fours;
      dataFile<<a.fives;
      dataFile<<a.sixes;
      dataFile<<a.thkind;
      dataFile<<a.frkind;
      dataFile.close(); // Close the file
    
       //delete dynamic array;
       delete [] arr2;  
       delete [] arr3;
//exit files
return 0;
}
void disResult(int *a,int s)
   {//enter function 
   int * current=a;
   for(int i=0; i<s; i++){
   cout<<"Dice face value: "<<*current<<endl;
   current++;}

}//exit function
void disR1 (int a[],int s){       
   cout<<"Player rolled: "<<endl;
   for(int i=0; i<s; i++){
   cout<<"Dice face value: "<<a[i]<<endl;    
   }}

void disR1V(vector<int>l){  
   for(int i=0; i<l.size(); i++){
   cout<<"Dice face value: "<<l[i]<<" (held)"<<endl;}
   }
    
void disR2V(vector<int>listb){
   for(int i=0; i<listb.size(); i++){
   cout<<"Dice face value: "<<listb[i]<<" (held)"<<endl;}}
void getRoll (int a[], int n, int MAX, int MIN){
   for(int i=0; i<n; i++){
   a[i]=(rand() % (MAX- MIN+ 1)) + MIN;}
}
void disMenu(){
   cout<<setw (20)<<right<<"Category"<< setw (16)<< right<<"Choice"<<endl;
   cout<<setw (16)<<right<<"Ones  "<<setw(24)<<right<<"Enter 1" << endl;
   cout<<setw (16)<<right<<" Twos  "<<setw(24)<<right<<"Enter 2 " << endl;
   cout<<setw (16)<<right<<"Three  "<<setw(24)<<right<<"Enter 3 " << endl;
   cout<<setw (16)<<right<<"Fours  "<<setw(24)<<right<<"Enter 4 " << endl;
   cout<<setw (16)<<right<<"Fives  "<<setw(24)<<right<<"Enter 5 " << endl;
   cout<<setw (16)<<right<<"Sixes  "<<setw(24)<<right<<"Enter 6 " << endl;
   cout<<setw (16)<<right<<"3 of Kind"<<setw(24)<<right<<"Enter 7 " << endl;
   cout<<setw (16)<<right<<"4 of Kind"<<setw(24)<<right<<"Enter 8 " << endl;
   cout<<"Yahtzee(50 points), Large Straigt (40 points), Small Straight (30"
     <<" points), Full House (25 points)." <<endl;
   cout<<"If you want to enter fixed value categories.  Enter 0"
   <<" user will enter values at end of game"<<endl;
}
 
Game getInfo (){   
Game tempGame;//temporary structure variable
short int choice;
cout << "Enter your choice" << endl;//user will give his choice
cin >> choice;

switch (choice)//switch statement will categorize use response
 {//enter switch statement   
 case 1:{cout << "Receive 1 points for each 1 rolled.  Input sum. " << endl; 
 cin >> tempGame.ones;
 break;}     
 case 2:{cout << "Receive 2 points for each 2 rolled.  Input sum. " << endl;
 cin >> tempGame.twos;
 break;}
 case 3:{cout << "Receive 3 points for each 3 rolled.  Input sum. " << endl; 
 cin >> tempGame.threes;
 break;}     
 case 4:{cout << "Receive 4 points for each 4 rolled.  Input sum. " << endl;
 cin >> tempGame.fours;
 break;} 
 case 5:{cout << "Receive 5 points for each 5 rolled.  Input sum. " << endl;
 cin >> tempGame.fives;
 break;}
 case 6:{cout << "Receive 6 points for each 6 rolled.  Input sum. " << endl;	
 cin >> tempGame.sixes;
 break;}
 case 7:{cout << "Three of a kind-add and input sum. " << endl;
cin >> tempGame.thkind;
break;} 
case 8:{cout <<"Four of a kind-add and input sum. " << endl;
cin >> tempGame.frkind;
break;} 
default:{
cout << "You did not enter a number between 1 through 13"<<endl;}//exit switch statement
}
return tempGame;}//return the temporary variable
 int getValue(int & v){
     cout<<"full house=25, small straight=30, large straight=40, yahtzee=50";
     cout<<" chance sum of dice amount ";
     cin>>v;
     return v;}
 void getScor (ScorInfo &c, int r){   
    switch (r){
        case 9:{cout<<"Enter 30 for small straight.  0 to pass."<<endl;
        cin>>c.smlStrt;
        break;}
        case 10:{cout<<"Enter 40 large straight.  0 to pass. "<<endl;
        cin>>c.larStrt;
        break;}
        case 11:{cout<<"Enter 50 for Yahtzee.  0 to pass. "<<endl;
        cin>>c.yahtzee;
        break;}
        case 12:{cout<<"Dice score for bonue.  0 to pass. "<<endl;
        cin>>c.bonus;
        break;}
        case 13:{cout<<"Dice score for full house.  0 to pass. "<<endl;
        cin>>c.fulHs;
        break;}        
        default:{
        cout <<"You did not enter a number between 1 through 13"<<endl;}
    }}
   void prtScor (ScorInfo c, string scr[]){
     
         cout<<scr[0]<<setw(30)<<right<<c.smlStrt<<endl;
         cout<<scr[1]<<setw(30)<<right<<c.larStrt<<endl;
         cout<<scr[2]<<setw(34)<<right<<c.yahtzee<<endl;
         cout<<scr[3]<<setw(42)<<right<<c.bonus<<endl;
         cout<<scr[4]<<setw(34)<<right<<c.fulHs<<endl;}


 





  

