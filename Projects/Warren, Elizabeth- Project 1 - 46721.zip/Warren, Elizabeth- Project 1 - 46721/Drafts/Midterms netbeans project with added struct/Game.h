/*
 *File: Game.h
 * Author:Elizabeth Warren
 * Purpose: Create a structure to hold game players
 * July 12 2020, 1:32 PM
 */

/* 
 * File:   Game.h
 * Author: rcc
 *
 * Created on July 14, 2020, 10:37 AM
 */

#ifndef GAME_H
#define GAME_H
struct Game{
    
    int ones;//how many 1s player rolled
    int twos;//how many 2s player rolled
    int threes;//how many 3s player rolled
    int fours;//how many 4s player rolled
    int fives;//how many 5s player rolled
    int sixes;//how many 6s player rolled
    int thkind;//three of a kind-any combination 
    int frkind;//four of a kind-any combination
    
};     
#endif /* GAME_H */

