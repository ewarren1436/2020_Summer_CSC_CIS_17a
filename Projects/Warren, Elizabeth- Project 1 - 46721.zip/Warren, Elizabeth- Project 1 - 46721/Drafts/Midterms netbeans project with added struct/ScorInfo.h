/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   ScorInfo.h
 * Author: Elizabeth Warren
 *
 * Created on July 15, 2020, 9:38 PM
 */

#ifndef SCORINFO_H
#define SCORINFO_H
struct ScorInfo{
int smlStrt;
int larStrt;
int yahtzee;
int bonus;
int fulHs;};

#endif /* SCORINFO_H */

